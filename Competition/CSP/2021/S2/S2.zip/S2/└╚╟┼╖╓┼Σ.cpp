/*Author��AustinJiang
��Ŀ�����ŷ���
ʱ�临�Ӷȣ�O()
�㷨��
��Դ��CSP 2021 S2
˼·��
*/
#include<bits/stdc++.h>
#define ll long long
#define pb push_back
#define mp make_pair
#define fir first
#define sec second
#define endl "\n"
#define random(a,b) rand()%(b-a+1)+a
#define PI pair<int,int>
#define VI vector<int>
#define VPI vector<PI>
#define PQ priority_queue
using namespace std;
const int INF=0x3f3f3f3f;
const int N=1e5+10;

int n,m[2],ans,num[N<<1],sum[N<<3];

struct plane{
	int a,b;
} t[2][N];

bool cmp(plane a,plane b){
	return a.a<b.a;
}

int find(int l,int r,int x){
	while(l<=r){
		int mid=l+r>>1;
		if(num[mid]>x) r=mid-1;
		else if(num[mid]<x) l=mid+1;
		else return mid;
	}
}

void update(int rt,int l,int r,int x,int y){
	if(l==r){
		sum[rt]+=y;
		return;
	}
	int mid=l+r>>1;
	if(x<=mid) update(rt<<1,l,mid,x,y);
	else update(rt<<1|1,mid+1,r,x,y);
	sum[rt]=sum[rt<<1]+sum[rt<<1|1];
}

int query(int rt,int l,int r,int x,int y){
	if(l==x&&r==y) return sum[rt];
	int mid=l+r>>1;
	if(y<=mid) return query(rt<<1,l,mid,x,y);
	else if(x>mid) return query(rt<<1|1,mid+1,r,x,y);
	else return query(rt<<1,l,mid,x,mid)+query(rt<<1|1,mid+1,r,mid+1,y);
}

int check(int x,int j){
	memset(sum,0,sizeof(sum));
	int res=0;
	for(int i=1;i<=m[j];i++){
		if(query(1,1,m[j]*2,1,t[j][i].a)<x){
			update(1,1,m[j]*2,t[j][i].a,1);
			update(1,1,m[j]*2,t[j][i].b,-1);
			res++;
		}
	}
	return res;
}

signed main(){
	ios::sync_with_stdio(false);
	cin.tie(0);
	cin>>n>>m[0]>>m[1];
	for(int j=0;j<2;j++){		
		for(int i=1;i<=m[j];i++){
			cin>>t[j][i].a>>t[j][i].b;
			num[i]=t[j][i].a;
			num[m[j]+i]=t[j][i].b;
		}
		sort(num+1,num+m[j]*2+1);
		for(int i=1;i<=m[j];i++){
			t[j][i].a=find(1,m[j]*2,t[j][i].a);
			t[j][i].b=find(1,m[j]*2,t[j][i].b);
		}
		sort(t[j]+1,t[j]+m[j]+1,cmp);
	}
	for(int i=0;i<=n;i++)
		ans=max(ans,check(i,0)+check(n-i,1));
	cout<<ans<<endl;
	return 0;
}

