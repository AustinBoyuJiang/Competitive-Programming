/*Author��AustinJiang
��Ŀ���������� 
ʱ�临�Ӷȣ�O(n)
�㷨��STL
��Դ��CSP 2021 J2 */
#include<bits/stdc++.h>
#define ll long long
#define pb push_back
#define mp make_pair
#define fir first
#define sec second
#define endl "\n"
#define random(a,b) rand()%(b-a+1)+a
#define PI pair<int,int>
#define VI vector<int>
#define VPI vector<PI>
#define PQ priority_queue
using namespace std;
const int INF=0x3f3f3f3f;
const int N=1e5+10;

int n;
map<string,int> servers;

bool check(string ip){
	int res=0,i;
	for(i=0;i<ip.size();i++){
		if(ip[i]=='.'||ip[i]==':'){
			if(res>255) return 0;
			res=0;
			if(ip[i]==':') break;
		}
		else{
			res*=10;
			res+=ip[i]-'0';
		}
	}
	for(i++;i<ip.size();i++){
		res*=10;
		res+=ip[i]-'0';
	}
	return res<=65535;
}

signed main(){
	ios::sync_with_stdio(false);
	cin.tie(0);
	cin>>n;
	for(int i=1;i<=n;i++){
		string type,ip;
		cin>>type>>ip;
		check(ip);
		if(type=="Server"){
			if(!check(ip)) cout<<"ERR"<<endl;
			else if(servers[ip]) cout<<"FAIL"<<endl;
			else servers[ip]=i,cout<<"OK"<<endl;
		}
		else{
			if(!check(ip)) cout<<"ERR"<<endl;
			else if(!servers[ip]) cout<<"FAIL"<<endl;
			else cout<<servers[ip]<<endl;
		}
	}
	return 0;
}

